import React from "react";
import { View, Text } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import Icon from "react-native-vector-icons/Ionicons";

// Import halaman Beranda dan Kategori Ormawa
import Beranda from "./Beranda"; // Sesuaikan path file ini
import KategoriOrmawa from "./KategoriOrmawa"; // Impor KategoriOrmawa.js

// Placeholder untuk halaman lainnya
function InformasiPendaftaranScreen() {
  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <Text>Informasi Pendaftaran</Text>
    </View>
  );
}

function FAQScreen() {
  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <Text>FAQ</Text>
    </View>
  );
}

function GaleriScreen() {
  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <Text>Galeri</Text>
    </View>
  );
}

// Membuat Bottom Tab Navigator
const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarIcon: ({ color, size }) => {
            let iconName;
            if (route.name === "Beranda") {
              iconName = "home-outline";
            } else if (route.name === "Kategori Ormawa") {
              iconName = "grid-outline";
            } else if (route.name === "Informasi Pendaftaran") {
              iconName = "information-circle-outline";
            } else if (route.name === "FAQ") {
              iconName = "help-circle-outline";
            } else if (route.name === "Galeri") {
              iconName = "images-outline";
            }
            return <Icon name={iconName} size={size} color={color} />;
          },
          tabBarActiveTintColor: "#5E27FD",
          tabBarInactiveTintColor: "gray",
        })}
      >
        {/* Halaman Beranda dan Kategori Ormawa di sini terhubung dengan file masing-masing */}
        <Tab.Screen name="Beranda" component={Beranda} />
        <Tab.Screen name="Kategori Ormawa" component={KategoriOrmawa} />
        <Tab.Screen
          name="Informasi Pendaftaran"
          component={InformasiPendaftaranScreen}
        />
        <Tab.Screen name="FAQ" component={FAQScreen} />
        <Tab.Screen name="Galeri" component={GaleriScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
