import React from "react";
import { SafeAreaView, View, ScrollView, Text, TouchableOpacity, StyleSheet, Image } from "react-native";

export default (props) => {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView horizontal={false} style={styles.scrollView}>
        <View style={styles.column}>
          {/* Kategori Ormawa */}
          <TouchableOpacity style={[styles.button, styles.square]}>
            <Text style={styles.text}>{"KATEGORI ORMAWA"}</Text>
          </TouchableOpacity>

          {/* Deskripsi Kategori Ormawa */}
          <View style={[styles.square]}>
            <Text style={styles.description}>
              {"Dapatkan Informasi Seputar Organisasi Mahasiswa Disini"}
            </Text>
          </View>

          {/* Universitas Button */}
          <TouchableOpacity style={[styles.button, styles.large]}>
            <View style={styles.iconTextContainer}>
              <Image 
                source={{uri: "https://img.icons8.com/ios-filled/50/ffffff/university.png"}} 
                style={styles.icon} 
              />
              <View style={styles.textContainer}>
                <Text style={styles.text}>{"UNIVERSITAS"}</Text>
                <Text style={styles.subText}>
                  {"Cari organisasi mahasiswa tingkat\nUniversitas disini!"}
                </Text>
              </View>
            </View>
          </TouchableOpacity>

          {/* Fakultas Button */}
          <TouchableOpacity style={[styles.button, styles.large]}>
            <View style={styles.iconTextContainer}>
              <Image 
                source={{uri: "https://img.icons8.com/ios-filled/50/ffffff/school.png"}} 
                style={styles.icon} 
              />
              <View style={styles.textContainer}>
                <Text style={styles.text}>{"FAKULTAS"}</Text>
                <Text style={styles.subText}>
                  {"Cari organisasi mahasiswa tingkat\nFakultas disini!"}
                </Text>
              </View>
            </View>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFFFFF",
  },
  scrollView: {
    paddingBottom: 21,
  },
  column: {
    width: "100%",
    alignItems: "center",
  },
  button: {
    borderRadius: 10,
    backgroundColor: "#3470A2",
    marginBottom: 16,
    paddingHorizontal: 16,
    paddingVertical: 10,
  },
  square: {
    width: 200,
    height: 60,
    justifyContent: "center",
    alignItems: "center",
  },
  large: {
    width: 380,
    height: 250,
    justifyContent: "center",
    padding: 16,
  },
  text: {
    color: "#FFFFFF",
    fontSize: 18,
    fontWeight: "bold",
  },
  subText: {
    color: "#FFFFFF",
    fontSize: 12,
    textAlign: "center",
  },
  description: {
    fontSize: 12,
    textAlign: "center",
    marginHorizontal: 8,
  },
  iconTextContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "flex-start",
  },
  icon: {
    width: 50,
    height: 50,
    marginRight: 16,
  },
  textContainer: {
    flex: 1,
    justifyContent: "center",
  },
});
