import React, { useState } from "react";
import { SafeAreaView, View, ScrollView, TouchableOpacity, Text, TextInput } from "react-native";
import Icon from 'react-native-vector-icons/FontAwesome'; // Mengimpor FontAwesome untuk ikon

export default (props) => {
    const [searchQuery, setSearchQuery] = useState(''); // State untuk menyimpan query pencarian

    return (
        <SafeAreaView style={{ flex: 1, alignItems: "flex-start", backgroundColor: "#FFFFFF" }}>
            <ScrollView
                style={{
                    flex: 1,
                    backgroundColor: "#FFFFFF",
                    borderRadius: 32,
                    shadowColor: "#00000040",
                    shadowOpacity: 0.3,
                    shadowOffset: { width: 0, height: 4 },
                    shadowRadius: 4,
                    elevation: 4,
                }}>
                <View style={{ marginBottom: 53, position: 'relative' }}>
                    {/* Persegi biru */}
                    <View style={{
                        backgroundColor: "#3470A2",
                        width: '100%',
                        height: 315,
                        paddingTop: 72,
                        paddingBottom: 33,
                        borderTopLeftRadius: 32,
                        borderTopRightRadius: 32,
                        borderBottomLeftRadius: 32,
                        borderBottomRightRadius: 32,
                    }}>
                        {/* Menambahkan seperempat lingkaran di kanan bawah */}
                        <View style={{
                            position: 'absolute',
                            bottom: 0,
                            right: 0,
                            width: 250, // Lebar seperempat lingkaran
                            height: 250, // Tinggi seperempat lingkaran
                            backgroundColor: "#63ABE6",
                            borderTopLeftRadius: 350, // Membuat seperempat lingkaran
                        }} />
                        <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 0, marginBottom: 48, marginHorizontal: 19 }}>
                            <View style={{ width: 101, flexDirection: "row", alignItems: "center" }}>
                                <TouchableOpacity style={{ flex: 1 }}>
                                    <Icon name="home" size={34} color="#FFFFFF" />
                                </TouchableOpacity>
                            </View>
                            {/* Ikon notifikasi */}
                            <Icon name="bell" size={34} color="#FFFFFF" />
                        </View>
                        <Text style={{ color: "#FFFFFF", fontSize: 18, marginBottom: 22, marginHorizontal: 35, width: 328 }}>
                            {"Selamat Datang, \nMuhammad Hadi Alfarisy"}
                        </Text>
                        <Text style={{ color: "#FFFFFF", fontSize: 12, marginBottom: 49, marginHorizontal: 35, width: 328 }}>
                            {"Dapatkan Informasi Seputar Organisasi Mahasiswa Disini"}
                        </Text>

                        {/* Search Engine */}
                        <View style={{ backgroundColor: "#F7F8FA", borderRadius: 24, paddingVertical: 9, paddingHorizontal: 15, marginBottom: 31, marginHorizontal: 45 }}>
                            <View style={{ flexDirection: "row", alignItems: "center" }}>
                                <Icon name="search" size={21} color="#8C8994" style={{ marginRight: 10 }} />
                                <TextInput
                                    style={{ flex: 1, color: "#8C8994" }}
                                    placeholder="Cari Ormawa"
                                    placeholderTextColor="#8C8994"
                                    value={searchQuery}
                                    onChangeText={setSearchQuery}
                                />
                            </View>
                            <View style={{ height: 1, backgroundColor: "#000000" }}></View>
                        </View>

                    </View>

                    <Text style={{ color: "#002649", fontSize: 20, marginLeft: 20, marginTop: 30, marginBottom: 20 }}>
                        {"Seputar Ormawa"}
                    </Text>
                    
                    {/* Tombol Kategori Ormawa, Informasi Pendaftaran, FAQ, dan Galeri */}
                    <View style={{ flexDirection: "row", justifyContent: "space-around", marginBottom: 30 }}>
                        <TouchableOpacity style={styles.button}>
                            <Icon name="folder" size={24} color="#FFFFFF" />
                            <Text style={styles.buttonText}>Kategori Ormawa</Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.button}>
                            <Icon name="info-circle" size={24} color="#FFFFFF" />
                            <Text style={styles.buttonText}>Informasi Pendaftaran</Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.button}>
                            <Icon name="question-circle" size={24} color="#FFFFFF" />
                            <Text style={styles.buttonText}>FAQ</Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.button}>
                            <Icon name="image" size={24} color="#FFFFFF" />
                            <Text style={styles.buttonText}>Galeri</Text>
                        </TouchableOpacity>
                    </View>
                </View>

                <Text style={{ color: "#002549", fontSize: 20, marginBottom: 7, marginLeft: 21 }}>
                    {"Berita Ormawa"}
                </Text>
                <Text style={{ color: "#7D8BB7", fontSize: 12, marginBottom: 11, marginLeft: 20 }}>
                    {"Update terus berita seputar ormawa disini!"}
                </Text>
                <ScrollView horizontal style={{ flexDirection: "row", marginBottom: 22, marginHorizontal: 18 }}>
                    <View style={styles.newsCard}>
                        <Icon name="file-text" size={100} color="#3470A2" />
                        <View style={styles.cardContent}>
                            <Text style={styles.cardTitle}>{"Pemilihan Ketua & Wakil BEM Unsri"}</Text>
                        </View>
                    </View>
                    <View style={styles.newsCard}>
                        <Icon name="file-text" size={100} color="#3470A2" />
                        <View style={styles.cardContent}>
                            <Text style={styles.cardTitle}>{"Pemilihan Ketua BEM FT Unsri"}</Text>
                        </View>
                    </View>
                    <View style={styles.newsCard}>
                        <Icon name="file-text" size={100} color="#3470A2" />
                        <View style={styles.cardContent}>
                            <Text style={styles.cardTitle}>{"Oprec Staff BEM Unsri"}</Text>
                        </View>
                    </View>
                </ScrollView>
                <View style={{ backgroundColor: "#FFFFFF", borderColor: "#5E27FD", borderWidth: 1, paddingVertical: 1 }}>
                    <View style={{ height: 2, backgroundColor: "#D9D9D9", marginBottom: 8 }}></View>
                    <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginHorizontal: 30 }}></View>
                </View>
            </ScrollView>
        </SafeAreaView>
    );
};

const styles = {
    button: {
        width: 80,
        height: 80, // Ukuran persegi
        backgroundColor: "#3470A2", // Ubah warna menjadi biru
        borderRadius: 8,
        justifyContent: "center",
        alignItems: "center",
    },
    buttonText: {
        color: "#FFFFFF",
        fontSize: 12,
        marginTop: 5, // Menambahkan jarak antara ikon dan teks
    },
    newsCard: {
        width: 150,
        alignSelf: "flex-start",
        borderColor: "#F2F2F2",
        borderRadius: 10,
        borderWidth: 1,
        marginRight: 15,
    },
    cardContent: {
        backgroundColor: "#FFFFFF",
        paddingVertical: 18,
        paddingHorizontal: 16,
    },
    cardTitle: {
        color: "#002549",
        fontSize: 16,
        width: 116,
    },
};
