import React, { useState } from "react";
import { SafeAreaView, View, ScrollView, TouchableOpacity, Text, TextInput, Image } from "react-native";
import Icon from 'react-native-vector-icons/FontAwesome';
import { useNavigation } from '@react-navigation/native'; // Impor useNavigation untuk navigasi

export default (props) => {
    const [searchQuery, setSearchQuery] = useState('');
    const navigation = useNavigation(); // Dapatkan objek navigation

    return (
        <SafeAreaView style={{ flex: 1, alignItems: "flex-start", backgroundColor: "#FFFFFF" }}>
            <ScrollView
                style={{
                    flex: 1,
                    backgroundColor: "#FFFFFF",
                    borderRadius: 32,
                    shadowColor: "#00000040",
                    shadowOpacity: 0.3,
                    shadowOffset: { width: 0, height: 4 },
                    shadowRadius: 4,
                    elevation: 4,
                }}>
                <View style={{ marginBottom: 53, position: 'relative' }}>
                    <View style={{
                        backgroundColor: "#3470A2",
                        width: '100%',
                        height: 315,
                        paddingTop: 72,
                        paddingBottom: 33,
                        borderTopLeftRadius: 0,
                        borderTopRightRadius: 0,
                        borderBottomLeftRadius: 32,
                        borderBottomRightRadius: 32,
                    }}>
                        <View style={{
                            position: 'absolute',
                            bottom: 0,
                            right: 0,
                            width: 250,
                            height: 250,
                            backgroundColor: "#63ABE6",
                            borderTopLeftRadius: 350,
                            borderBottomRightRadius: 40,
                        }} />

                        {/* Ganti Tombol Home menjadi Logo dengan tulisan Ormawa */}
                        <View style={{ flexDirection: "row", justifyContent: "space-between", alignItems: "center", marginTop: 0, marginBottom: 48, marginHorizontal: 19 }}>
                            <View style={{ width: 150, flexDirection: "row", alignItems: "center" }}>
                                {/* Logo */}
                                <Image
                                    source={require('C:/Users/User/Zann/assets/logo_direktori.png')}
                                    style={{ width: 41, height: 41 }} // Sesuaikan ukuran logo
                                />
                                {/* Tulisan Ormawa */}
                                <View style={styles.ormaTextContainer}>
                                    <Text style={styles.ormaText}>Ormawa</Text>
                                </View>
                            </View>
                            <TouchableOpacity>
                            <View style={{
                            position: 'absolute',
                            top: -9,
                            bottom: 0,
                            right: 6,
                            width: 45,
                            height: 45,
                            backgroundColor: "#FFFFFF",
                            borderTopLeftRadius: 25,
                            borderBottomLeftRadius: 25,
                            borderTopRightRadius: 25,
                            borderBottomRightRadius: 25,
                        }} />
                            <Icon name="bell" size={28} color="#FFC727" style={{ right: 14, top: -1}}/>
                            </TouchableOpacity>
                        </View>
                        <View style={styles.mainCard}>
                        <View style={styles.mainCardContent}>
                            <Text style={styles.mainCardTitle}>Selamat Datang, </Text>
                            <Text style={styles.mainCardTitle}>Intelektual Sriwijaya Muda </Text>
                            <Text style={styles.mainCardSubtitle}>
                              Dapatkan Informasi Seputar Organisasi Mahasiswa Disini
                            </Text>
                        </View>
                        </View>
                        {/* Search Engine */}
                        <View style={{ backgroundColor: "#F7F8FA", borderRadius: 24, paddingVertical: 9, paddingHorizontal: 15, marginBottom: 31, marginHorizontal: 45 }}>
                            <View style={{ flexDirection: "row", alignItems: "center" }}>
                                <Icon name="search" size={21} color="#8C8994" style={{ marginRight: 10 }} />
                                <TextInput
                                    style={{ flex: 1, color: "#8C8994" }}
                                    placeholder="Cari Ormawa"
                                    placeholderTextColor="#8C8994"
                                    value={searchQuery}
                                    onChangeText={setSearchQuery}
                                />
                            </View>
                            <View style={{ height: 1, backgroundColor: "#000000" }}></View>
                        </View>
                    </View>

                    <Text style={{ color: "#002649", fontSize: 20, marginLeft: 20, marginTop: 30, marginBottom: 20 }}>
                        {"Seputar Ormawa"}
                    </Text>
                    
                    {/* Tombol Kategori Ormawa */}
                    <View style={{ flexDirection: "row", justifyContent: "space-around", marginBottom: 30 }}>
                        <TouchableOpacity
                            style={styles.button}
                            onPress={() => navigation.navigate('Kategori Ormawa')} // Navigasi ke halaman Kategori Ormawa
                        >
                            <Icon name="folder" size={24} color="#FFFFFF" />
                            <Text style={styles.buttonText}>Kategori Ormawa</Text>
                        </TouchableOpacity>
                        <TouchableOpacity 
                            style={styles.button}
                            onPress={() => navigation.navigate('Informasi')} 
                        >
                            <Icon name="info-circle" size={24} color="#FFFFFF" />
                            <Text style={styles.buttonText}>Informasi</Text>
                        </TouchableOpacity>
                        <TouchableOpacity 
                            style={styles.button}
                            onPress={() => navigation.navigate('FAQ')} 
                        >
                            <Icon name="question-circle" size={24} color="#FFFFFF" />
                            <Text style={styles.buttonText}>FAQ</Text>
                        </TouchableOpacity>
                        <TouchableOpacity style={styles.button}>
                            <Icon name="image" size={24} color="#FFFFFF" />
                            <Text style={styles.buttonText}>Galeri</Text>
                        </TouchableOpacity>
                    </View>
                </View>

                <Text style={{ color: "#002549", fontSize: 20, marginBottom: 7, marginLeft: 21 }}>
                    {"Berita Ormawa"}
                </Text>
                {/* Berita Ormawa */}
                <ScrollView horizontal style={{ flexDirection: "row", marginBottom: 22, marginHorizontal: 18 }}>
                    <View style={styles.newsCard}>
                        <Icon name="file-text" size={100} color="#3470A2" />
                        <View style={styles.cardContent}>
                            <Text style={styles.cardTitle}>{"Pemilihan Ketua & Wakil BEM Unsri"}</Text>
                        </View>
                    </View>
                    <View style={styles.newsCard}>
                        <Icon name="file-text" size={100} color="#3470A2" />
                        <View style={styles.cardContent}>
                            <Text style={styles.cardTitle}>{"Pemilihan Ketua BEM FT Unsri"}</Text>
                        </View>
                    </View>
                    <View style={styles.newsCard}>
                        <Icon name="file-text" size={100} color="#3470A2" />
                        <View style={styles.cardContent}>
                            <Text style={styles.cardTitle}>{"Oprec Staff BEM Unsri"}</Text>
                        </View>
                    </View>
                </ScrollView>
            </ScrollView>
        </SafeAreaView>
    );
};

const styles = {
    button: {
        width: 80,
        height: 80,
        backgroundColor: "#3470A2",
        borderRadius: 8,
        justifyContent: "center",
        alignItems: "center",
    },
    buttonText: {
        color: "#FFFFFF",
        fontSize: 12,
        marginTop: 5,
    },
    ormaTextContainer: {
        backgroundColor: "#96B5CF", // Warna biru untuk persegi panjang
        borderTopRightRadius: 10,
        borderBottomRightRadius: 10, // Ujung tumpul
        paddingVertical: 9,
        paddingHorizontal: 15,
        marginLeft: -5,
    },
    ormaText: {
        color: "#FFFFFF",
        fontSize: 18,
        fontWeight: "bold",
    },
    newsCard: {
        width: 150,
        borderColor: "#F2F2F2",
        borderRadius: 10,
        borderWidth: 1,
        marginRight: 15,
    },
    mainCard: {
        position: "absolute",
        flexDirection: "row",
        backgroundColor: "#225580",
        borderRadius: 8,
        padding: 16,
        marginRight: 16,
        marginLeft: 16,
        marginTop: 160, 
        alignItems: "center",
        borderRadius: 20,
        elevation: 4,
        zIndex: 999,
      },
      mainCardContent: {
        flex: 1,
      },
      mainCardTitle: {
        color: "#FFFFFF",
        fontSize: 18,
        fontWeight: "bold",
        marginBottom: 4,
      },
      mainCardSubtitle: {
        color: "#FFFFFF",
        fontSize: 12,
      },
    cardContent: {
        backgroundColor: "#FFFFFF",
        paddingVertical: 18,
        paddingHorizontal: 16,
    },
    cardTitle: {
        color: "#002549",
        fontSize: 16,
        width: 116,
    },
};
