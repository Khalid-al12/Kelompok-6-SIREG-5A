import React from "react";
import { View, Text } from "react-native";
import { NavigationContainer } from "@react-navigation/native";
import { createBottomTabNavigator } from "@react-navigation/bottom-tabs";
import Icon from "react-native-vector-icons/Ionicons";

// Import halaman Beranda dan Kategori Ormawa
import Beranda from "./Beranda";
import KategoriOrmawa from "./KategoriOrmawa";
import FAQ from './FAQ'; // Import the Informasi component
import Informasi from "./Informasi";

function AkunScreen() {
  return (
    <View style={{ flex: 1, justifyContent: "center", alignItems: "center" }}>
      <Text>Akun</Text>
    </View>
  );
}

// Membuat Bottom Tab Navigator
const Tab = createBottomTabNavigator();

export default function App() {
  return (
    <NavigationContainer>
      <Tab.Navigator
        screenOptions={({ route }) => ({
          tabBarIcon: ({ color, size }) => {
            let iconName;
            if (route.name === "Beranda") {
              iconName = "home-outline";
            } else if (route.name === "Kategori Ormawa") {
              iconName = "grid-outline";
            } else if (route.name === "Informasi") {
              iconName = "information-circle-outline";
            } else if (route.name === "FAQ") {
              iconName = "help-circle-outline";
            } else if (route.name === "Akun") {
              iconName = "person-outline";
            }
            return <Icon name={iconName} size={size} color={color} />;
          },
          tabBarActiveTintColor: "#FFC727",
          tabBarInactiveTintColor: "gray",
          headerShown: false, // Menyembunyikan header pada semua tab
        })}
      >
        <Tab.Screen name="Beranda" component={Beranda} />
        <Tab.Screen name="Kategori Ormawa" component={KategoriOrmawa} />
        <Tab.Screen name="Informasi" component={Informasi} />
        <Tab.Screen name="FAQ" component={FAQ} />
        <Tab.Screen name="Akun" component={AkunScreen} />
      </Tab.Navigator>
    </NavigationContainer>
  );
}
