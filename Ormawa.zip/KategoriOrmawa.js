import React from "react";
import { SafeAreaView, View, ScrollView, Text, TouchableOpacity, StyleSheet, Image } from "react-native";

export default (props) => {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView horizontal style={styles.scrollView}>
        <View style={styles.column}>
          {/* Kategori Ormawa */}
          <TouchableOpacity style={[styles.button, styles.square]}>
            <Text style={styles.text}>{"KATEGORI ORMAWA"}</Text>
          </TouchableOpacity>

          {/* Deskripsi Kategori Ormawa */}
          <View style={[styles.square]}>
            <Text style={styles.description}>
              {"Dapatkan Informasi Seputar Organisasi Mahasiswa Disini"}
            </Text>
          </View>

          {/* Universitas Button */}
          <TouchableOpacity style={[styles.button, styles.large]}>
            <View style={styles.iconTextContainer}>
              <Image 
                source={{uri: "https://img.icons8.com/ios-filled/50/ffffff/university.png"}} 
                style={styles.icon} 
              />
              <View>
                <Text style={styles.text}>{"UNIVERSITAS"}</Text>
                <Text style={styles.subText}>
                  {"Cari organisasi mahasiswa tingkat\nUniversitas disini!"}
                </Text>
              </View>
            </View>
          </TouchableOpacity>

          {/* Fakultas Button */}
          <TouchableOpacity style={[styles.button, styles.large]}>
            <View style={styles.iconTextContainer}>
              <Image 
                source={{uri: "https://img.icons8.com/ios-filled/50/ffffff/school.png"}} 
                style={styles.icon} 
              />
              <View>
                <Text style={styles.text}>{"FAKULTAS"}</Text>
                <Text style={styles.subText}>
                  {"Dapatkan Informasi Seputar Organisasi Mahasiswa Disini"}
                </Text>
              </View>
            </View>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFFFFF",
  },
  scrollView: {
    paddingBottom: 21,
  },
  column: {
    width: 398,
    alignSelf: "flex-start",
  },
  button: {
    borderRadius: 10,
    backgroundColor: "#3470A2",
    alignItems: "center",
    justifyContent: "center",
    marginBottom: 16,
    marginHorizontal: 8,
  },
  square: {
    width: 200,
    height: 60,
  },
  large: {
    width: 380,
    height: 250,
  },
  text: {
    color: "#FFFFFF",
    fontSize: 18,
  },
  subText: {
    color: "#FFFFFF",
    fontSize: 12,
    textAlign: "center",
  },
  description: {
    fontSize: 12,
    textAlign: "center",
    marginHorizontal: 8,
  },
  iconTextContainer: {
    flexDirection: "row",
    alignItems: "center",
    justifyContent: "center",
    paddingHorizontal: 10,
  },
  icon: {
    width: 50,
    height: 50,
    marginRight: 10,
  },
});
