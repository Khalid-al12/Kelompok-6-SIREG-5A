import React from "react";
import {
  SafeAreaView,
  View,
  ScrollView,
  Text,
  Image,
  StyleSheet,
} from "react-native";
export default (props) => {
  return (
    <SafeAreaView style={styles.container}>
      <ScrollView style={styles.scrollView}>
        <View style={styles.column}>
          <View style={styles.row}>
            <View style={styles.column2}>
              <View style={styles.view}>
                <Text style={styles.text}>{"Profil Ormawa"}</Text>
              </View>
              <Image
                source={{ uri: "https://i.imgur.com/1tMFzp8.png" }}
                resizeMode={"stretch"}
                style={styles.absoluteImage}
              />
            </View>
            <View style={styles.row2}>
              <Image
                source={{ uri: "https://i.imgur.com/1tMFzp8.png" }}
                resizeMode={"stretch"}
                style={styles.image}
              />
              <Image
                source={{ uri: "https://i.imgur.com/1tMFzp8.png" }}
                resizeMode={"stretch"}
                style={styles.image}
              />
            </View>
          </View>
          <View style={styles.column3}>
            <View style={styles.row3}>
              <Image
                source={{ uri: "https://i.imgur.com/1tMFzp8.png" }}
                resizeMode={"stretch"}
                style={styles.image2}
              />
              <View style={styles.column4}>
                <Text style={styles.text2}>{"BEM FH Unsri"}</Text>
                <Text style={styles.text3}>
                  {"BEM Fakultas Hukum"}
                </Text>
              </View>
            </View>
            <Text style={styles.text5}>{"PROFIL SINGKAT"}</Text>
            <Text style={styles.text4}>
              {
                "Badan Eksekutif Mahasiswa (BEM) Fakultas adalah\norganisasi kemahasiswaan di tingkat fakultas yang\nbertujuan untuk memfasilitasi dan mewakili aspirasi \nmahasiswa dalam lingkup fakultas."
              }
            </Text>
            <Text style={styles.text5}>{"VISI"}</Text>
            <Text style={styles.text6}>
              {
                "Mewujudkan mahasiswa fakultas yang berintegritas, \ninovatif, dan berdaya saing tinggi, serta mampu \nmemberikan kontribusi positif bagi fakultas, masyarakat, \ndan bangsa."
              }
            </Text>
            <Text style={styles.text7}>{"MISI"}</Text>
            <Text style={styles.text8}>
              {
                "1. Meningkatkan kualitas akademik dan non-akademik mahasiswa di tingkat fakultas.\n2. Membangun solidaritas dan kepedulian sosial di lingkungan fakultas.\n3. Memperjuangkan aspirasi mahasiswa fakultas.\n4. Mengembangkan jiwa kepemimpinan dan organisasi mahasiswa fakultas.\n5. Mendorong kreativitas dan inovasi sesuai dengan bidang keilmuan fakultas."
              }
            </Text>
            <Text style={styles.text9}>{"Info Lebih Lanjut"}</Text>
            <View style={styles.row4}>
              <Image
                source={{ uri: "https://i.imgur.com/1tMFzp8.png" }}
                resizeMode={"stretch"}
                style={styles.image3}
              />
              <Image
                source={{ uri: "https://i.imgur.com/1tMFzp8.png" }}
                resizeMode={"stretch"}
                style={styles.image4}
              />
            </View>
          </View>
        </View>
      </ScrollView>
    </SafeAreaView>
  );
};
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#FFFFFF",
  },
  absoluteImage: {
    position: "absolute",
    top: 3,
    left: -3,
    width: 29,
    height: 29,
  },
  column: {
    backgroundColor: "#3470A2",
    paddingTop: 73,
    paddingBottom: 83,
    paddingHorizontal: 22,
  },
  column2: {
    width: 168,
    marginRight: 140,
  },
  column3: {
    backgroundColor: "#FCF4F4",
    borderColor: "#FFC727",
    borderRadius: 14,
    borderWidth: 1,
    paddingVertical: 40,
    paddingHorizontal: 24,
    shadowColor: "#00000040",
    shadowOpacity: 0.3,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
  },
  column4: {
    width: 203,
    alignSelf: "flex-start",
    marginTop: 12,
  },
  image: {
    width: 8,
    height: 18,
  },
  image2: {
    borderRadius: 14,
    width: 76,
    height: 76,
  },
  image3: {
    width: 24,
    height: 23,
    marginRight: 10,
  },
  image4: {
    width: 24,
    height: 23,
  },
  row: {
    flexDirection: "row",
    alignItems: "center",
    marginBottom: 60,
  },
  row2: {
    width: 35,
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    borderColor: "#FFFFFF",
    borderWidth: 1,
    padding: 9,
  },
  row3: {
    flexDirection: "row",
    justifyContent: "space-between",
    marginBottom: 39,
  },
  row4: {
    flexDirection: "row",
    alignItems: "center",
  },
  scrollView: {
    flex: 1,
    backgroundColor: "#FFFFFF",
    borderRadius: 32,
    shadowColor: "#00000040",
    shadowOpacity: 0.3,
    shadowOffset: {
      width: 0,
      height: 4,
    },
    shadowRadius: 4,
    elevation: 4,
  },
  text: {
    color: "#FFFFFF",
    fontSize: 18,
  },
  text2: {
    color: "#000000",
    fontSize: 18,
    marginBottom: 5,
    marginLeft: 10,
  },
  text3: {
    color: "#000000",
    fontSize: 12,
    marginLeft: 10,
  },
  text4: {
    color: "#000000",
    fontSize: 12,
    marginBottom: 34,
    marginLeft: 1,
    width: 300,
  },
  text5: {
    color: "#000000",
    fontSize: 18,
    marginBottom: 5,
  },
  text6: {
    color: "#000000",
    fontSize: 12,
    marginBottom: 29,
    width: 304,
  },
  text7: {
    color: "#000000",
    fontSize: 18,
    marginBottom: 7,
  },
  text8: {
    color: "#000000",
    fontSize: 12,
    marginBottom: 46,
    width: 304,
  },
  text9: {
    color: "#000000",
    fontSize: 14,
    marginBottom: 9,
  },
  view: {
    backgroundColor: "#D9D9D980",
    borderRadius: 5,
    paddingVertical: 9,
    paddingLeft: 36,
    paddingRight: 14,
  },
});
